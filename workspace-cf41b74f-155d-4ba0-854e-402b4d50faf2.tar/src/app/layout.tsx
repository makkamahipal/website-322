import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title:
    "AS Enterprise | Digital Marketing, Web Development & E-commerce in Kolkata",
  description:
    "AS Enterprise is a Kolkata-based digital agency offering digital marketing, e-commerce solutions, SEO, social media marketing and website development for growing businesses.",
  keywords: [
    "digital marketing Kolkata",
    "web development Kolkata",
    "e-commerce solutions",
    "SEO services",
    "social media marketing",
    "AS Enterprise",
    "digital agency Kolkata",
    "website development",
  ],
  icons: {
    icon: "/as-enterprise-logo.jpeg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
