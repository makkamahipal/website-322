import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { z } from "zod";

const PHONE_FORMAT_REGEX = /^[+]?[0-9\s\-().]{10,17}$/;

const enquirySchema = z.object({
  name: z
    .string({ message: "Name is required" })
    .trim()
    .min(2, "Name must be at least 2 characters")
    .max(120, "Name must be at most 120 characters"),
  email: z
    .string({ message: "Email is required" })
    .trim()
    .toLowerCase()
    .max(200, "Email must be at most 200 characters")
    .email("Please enter a valid email address"),
  phone: z
    .string({ message: "Phone number is required" })
    .trim()
    .regex(PHONE_FORMAT_REGEX, "Please enter a valid phone number")
    .refine((value) => {
      const digitCount = value.replace(/\D/g, "").length;
      return digitCount >= 10 && digitCount <= 15;
    }, "Phone number must contain between 10 and 15 digits"),
  service: z.enum(
    [
      "Digital Marketing",
      "E-commerce",
      "SEO",
      "Social Media Marketing",
      "Website Development",
      "Other",
    ],
    { message: "Please select a valid service" }
  ),
  message: z
    .string()
    .trim()
    .max(2000, "Message must be at most 2000 characters")
    .optional()
    .default(""),
});

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { success: false, error: "Invalid JSON body" },
      { status: 400 }
    );
  }

  const parsed = enquirySchema.safeParse(body);
  if (!parsed.success) {
    const firstIssue = parsed.error.issues[0];
    return NextResponse.json(
      {
        success: false,
        error: firstIssue?.message ?? "Validation failed. Please check your input.",
      },
      { status: 400 }
    );
  }

  const { name, email, phone, service, message } = parsed.data;

  try {
    await db.enquiry.create({
      data: { name, email, phone, service, message },
    });
  } catch (error) {
    console.error("Failed to save enquiry:", error);
    return NextResponse.json(
      { success: false, error: "Something went wrong. Please try again later." },
      { status: 500 }
    );
  }

  return NextResponse.json(
    {
      success: true,
      message:
        "Enquiry submitted successfully. Our team will contact you within 24 hours.",
    },
    { status: 201 }
  );
}

export async function GET() {
  return NextResponse.json({
    success: true,
    message: "AS Enterprise enquiry API is live",
  });
}
