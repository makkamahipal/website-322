"use client";

import { useCallback, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

import { AboutView } from "@/components/as-enterprise/about-view";
import { ContactView } from "@/components/as-enterprise/contact-view";
import { EnquiryView } from "@/components/as-enterprise/enquiry-view";
import { HomeView } from "@/components/as-enterprise/home-view";
import { ServicesView } from "@/components/as-enterprise/services-view";
import { SiteFooter } from "@/components/as-enterprise/site-footer";
import { SiteHeader } from "@/components/as-enterprise/site-header";
import type { NavigateFn, View } from "@/components/as-enterprise/types";

export default function Home() {
  const [view, setView] = useState<View>("home");
  const [selectedService, setSelectedService] = useState<string>("");

  const navigate: NavigateFn = useCallback((nextView, service) => {
    if (service !== undefined) {
      setSelectedService(service);
    }
    setView(nextView);
    window.scrollTo({ top: 0, behavior: "instant" });
  }, []);

  const renderView = () => {
    switch (view) {
      case "home":
        return <HomeView onNavigate={navigate} />;
      case "about":
        return <AboutView onNavigate={navigate} />;
      case "services":
        return <ServicesView onNavigate={navigate} />;
      case "contact":
        return <ContactView onNavigate={navigate} />;
      case "enquiry":
        return <EnquiryView selectedService={selectedService} />;
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-white font-sans text-neutral-950">
      <SiteHeader view={view} onNavigate={navigate} />
      <main className="flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>
      <SiteFooter onNavigate={navigate} />
    </div>
  );
}
