export type View = "home" | "about" | "services" | "contact" | "enquiry";

export type NavigateFn = (view: View, service?: string) => void;
