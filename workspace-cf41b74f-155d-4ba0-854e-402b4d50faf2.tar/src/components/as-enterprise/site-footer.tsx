"use client";

import Image from "next/image";

import { CONTACT, LOGO_SRC, SERVICES } from "./site-data";
import type { NavigateFn } from "./types";

const QUICK_LINKS: Array<{ label: string; params: Parameters<NavigateFn> }> = [
  { label: "Home", params: ["home"] },
  { label: "About Us", params: ["about"] },
  { label: "Services", params: ["services"] },
  { label: "Contact Us", params: ["contact"] },
  { label: "Enquiry", params: ["enquiry"] },
];

interface SiteFooterProps {
  onNavigate: NavigateFn;
}

export function SiteFooter({ onNavigate }: SiteFooterProps) {
  const year = new Date().getFullYear();

  return (
    <footer className="mt-auto bg-neutral-950 text-neutral-400">
      <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 md:py-16 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-3">
              <Image
                src={LOGO_SRC}
                alt="AS Enterprise logo"
                width={44}
                height={44}
                className="h-11 w-11 rounded-lg bg-white object-cover invert"
              />
              <span className="text-lg font-semibold tracking-tight text-white">
                AS Enterprise
              </span>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-relaxed">
              A Kolkata-based digital agency helping businesses grow online
              with marketing, e-commerce and modern websites.
            </p>
          </div>

          <nav aria-label="Footer quick links">
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em] text-white">
              Quick Links
            </h3>
            <ul className="mt-4 space-y-1">
              {QUICK_LINKS.map((link) => (
                <li key={link.label}>
                  <button
                    type="button"
                    onClick={() => onNavigate(...link.params)}
                    className="min-h-11 py-2 text-sm outline-none transition-colors hover:text-white focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-neutral-950"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Footer services">
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em] text-white">
              Services
            </h3>
            <ul className="mt-4 space-y-1">
              {SERVICES.map((service) => (
                <li key={service.id}>
                  <button
                    type="button"
                    onClick={() => onNavigate("services")}
                    className="min-h-11 py-2 text-left text-sm outline-none transition-colors hover:text-white focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-neutral-950"
                  >
                    {service.title}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em] text-white">
              Contact
            </h3>
            <ul className="mt-4 space-y-3 text-sm">
              <li>
                <a
                  href={CONTACT.phonePrimaryHref}
                  className="outline-none transition-colors hover:text-white focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-neutral-950"
                >
                  {CONTACT.phonePrimary}
                </a>
              </li>
              <li>
                <a
                  href={CONTACT.phoneSecondaryHref}
                  className="outline-none transition-colors hover:text-white focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-neutral-950"
                >
                  {CONTACT.phoneSecondary}
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${CONTACT.email}`}
                  className="break-all outline-none transition-colors hover:text-white focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-neutral-950"
                >
                  {CONTACT.email}
                </a>
              </li>
              <li className="leading-relaxed">{CONTACT.address}</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="border-t border-neutral-800">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-6 text-xs sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
          <p>© {year} AS Enterprise. All rights reserved.</p>
          <p>Kolkata, West Bengal, India</p>
        </div>
      </div>
    </footer>
  );
}
