"use client";

import { Mail, MapPin, Phone, type LucideIcon } from "lucide-react";

import { Button } from "@/components/ui/button";

import { FadeIn } from "./motion";
import { CONTACT } from "./site-data";
import type { NavigateFn } from "./types";

const INFO_CARDS: Array<{
  icon: LucideIcon;
  title: string;
  lines: Array<{ text: string; href?: string }>;
}> = [
  {
    icon: Phone,
    title: "Call Us",
    lines: [
      { text: CONTACT.phonePrimary, href: CONTACT.phonePrimaryHref },
      { text: CONTACT.phoneSecondary, href: CONTACT.phoneSecondaryHref },
    ],
  },
  {
    icon: Mail,
    title: "Email Us",
    lines: [{ text: CONTACT.email, href: `mailto:${CONTACT.email}` }],
  },
  {
    icon: MapPin,
    title: "Visit Us",
    lines: [{ text: CONTACT.address }],
  },
];

interface ContactViewProps {
  onNavigate: NavigateFn;
}

export function ContactView({ onNavigate }: ContactViewProps) {
  return (
    <>
      {/* Header */}
      <section className="pt-16 pb-12 md:pt-24 md:pb-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <FadeIn className="max-w-2xl">
            <p className="text-xs font-medium uppercase tracking-[0.2em] text-neutral-500">
              Contact Us
            </p>
            <h1 className="mt-4 text-4xl font-semibold tracking-tight text-neutral-950 sm:text-5xl">
              Let&apos;s talk about your business.
            </h1>
            <p className="mt-6 text-base leading-relaxed text-neutral-600 md:text-lg">
              Call, email or visit us — whichever works for you. We are happy
              to discuss your project and suggest the best way forward.
            </p>
          </FadeIn>
        </div>
      </section>

      {/* Info cards */}
      <section className="py-8 md:py-12">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <FadeIn>
            <div className="grid gap-6 md:grid-cols-3">
              {INFO_CARDS.map((card) => (
                <div
                  key={card.title}
                  className="h-full rounded-2xl border border-neutral-200 bg-white p-6 transition-shadow hover:shadow-md md:p-8"
                >
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-neutral-950 text-white">
                    <card.icon className="size-5" aria-hidden="true" />
                  </div>
                  <h2 className="mt-5 text-lg font-semibold tracking-tight text-neutral-950">
                    {card.title}
                  </h2>
                  <div className="mt-3 space-y-2">
                    {card.lines.map((line) =>
                      line.href ? (
                        <a
                          key={line.text}
                          href={line.href}
                          className="block min-h-11 break-words py-1 text-sm leading-relaxed text-neutral-600 outline-none transition-colors hover:text-neutral-950 focus-visible:ring-2 focus-visible:ring-neutral-950 focus-visible:ring-offset-2"
                        >
                          {line.text}
                        </a>
                      ) : (
                        <p
                          key={line.text}
                          className="py-1 text-sm leading-relaxed text-neutral-600"
                        >
                          {line.text}
                        </p>
                      )
                    )}
                  </div>
                </div>
              ))}
            </div>
          </FadeIn>
        </div>
      </section>

      {/* Map */}
      <section className="py-8 md:py-12">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <FadeIn>
            <div className="overflow-hidden rounded-3xl border border-neutral-200">
              <iframe
                src="https://www.google.com/maps?q=Sir%20Ramesh%20Mitra%20Road%2C%20Narayanpur%2C%20Kolkata-700132&output=embed"
                className="h-[380px] w-full border-0"
                loading="lazy"
                title="AS Enterprise location map"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </FadeIn>
        </div>
      </section>

      {/* Callback CTA */}
      <section className="py-12 pb-20 md:py-16 md:pb-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <FadeIn>
            <div className="flex flex-col items-start justify-between gap-6 rounded-2xl border border-neutral-200 bg-neutral-50 p-6 md:flex-row md:items-center md:p-8">
              <div>
                <h2 className="text-xl font-semibold tracking-tight text-neutral-950 md:text-2xl">
                  Prefer a quick callback?
                </h2>
                <p className="mt-2 text-sm leading-relaxed text-neutral-600 md:text-base">
                  Send an enquiry and our team will call you back.
                </p>
              </div>
              <Button
                type="button"
                onClick={() => onNavigate("enquiry")}
                className="h-11 shrink-0 rounded-full bg-neutral-950 px-7 text-white hover:bg-neutral-800"
              >
                Submit Enquiry
              </Button>
            </div>
          </FadeIn>
        </div>
      </section>
    </>
  );
}
