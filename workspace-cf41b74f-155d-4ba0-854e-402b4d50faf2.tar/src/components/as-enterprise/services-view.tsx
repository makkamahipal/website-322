"use client";

import { Check } from "lucide-react";

import { Button } from "@/components/ui/button";

import { FadeIn, StaggerGroup, StaggerItem } from "./motion";
import { SERVICES } from "./site-data";
import type { NavigateFn } from "./types";

interface ServicesViewProps {
  onNavigate: NavigateFn;
}

export function ServicesView({ onNavigate }: ServicesViewProps) {
  return (
    <>
      {/* Header */}
      <section className="pt-16 pb-12 md:pt-24 md:pb-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <FadeIn className="max-w-2xl">
            <p className="text-xs font-medium uppercase tracking-[0.2em] text-neutral-500">
              Our Services
            </p>
            <h1 className="mt-4 text-4xl font-semibold tracking-tight text-neutral-950 sm:text-5xl">
              Services built for every stage of your growth.
            </h1>
            <p className="mt-6 text-base leading-relaxed text-neutral-600 md:text-lg">
              Five focused services, one accountable team. Pick what you need
              today and scale up whenever you are ready — we will handle the
              rest.
            </p>
          </FadeIn>
        </div>
      </section>

      {/* Service details */}
      <section className="bg-neutral-50 py-16 md:py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <StaggerGroup className="space-y-6">
            {SERVICES.map((service, index) => (
              <StaggerItem key={service.id}>
                <article className="rounded-2xl border border-neutral-200 bg-white p-6 transition-shadow hover:shadow-md md:p-8">
                  <div className="grid gap-8 lg:grid-cols-[1.1fr_1fr] lg:gap-12">
                    <div>
                      <div className="flex items-center gap-4">
                        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-neutral-950 text-white">
                          <service.icon className="size-5" aria-hidden="true" />
                        </div>
                        <p className="text-xs font-medium uppercase tracking-[0.2em] text-neutral-500">
                          Service {String(index + 1).padStart(2, "0")}
                        </p>
                      </div>
                      <h2 className="mt-5 text-2xl font-semibold tracking-tight text-neutral-950 md:text-3xl">
                        {service.title}
                      </h2>
                      <p className="mt-3 text-base leading-relaxed text-neutral-600">
                        {service.tagline}
                      </p>
                      <Button
                        type="button"
                        onClick={() => onNavigate("enquiry", service.title)}
                        className="mt-8 h-11 rounded-full bg-neutral-950 px-7 text-white hover:bg-neutral-800"
                      >
                        Enquire about this service
                      </Button>
                    </div>
                    <ul className="grid content-start gap-3 sm:grid-cols-2 lg:grid-cols-1">
                      {service.bullets.map((bullet) => (
                        <li
                          key={bullet}
                          className="flex items-start gap-3 rounded-xl border border-neutral-200 bg-neutral-50 px-4 py-3 text-sm text-neutral-600"
                        >
                          <Check
                            className="mt-0.5 size-4 shrink-0 text-neutral-950"
                            aria-hidden="true"
                          />
                          {bullet}
                        </li>
                      ))}
                    </ul>
                  </div>
                </article>
              </StaggerItem>
            ))}
          </StaggerGroup>

          <FadeIn className="mt-12 text-center">
            <p className="text-sm text-neutral-600">
              Not sure which service fits your goal? Reach out and we will
              recommend the right starting point.
            </p>
            <Button
              type="button"
              onClick={() => onNavigate("enquiry", "Other")}
              className="mt-6 h-11 rounded-full border border-neutral-300 bg-white px-7 text-neutral-900 hover:bg-neutral-100"
            >
              Ask a Question
            </Button>
          </FadeIn>
        </div>
      </section>
    </>
  );
}
