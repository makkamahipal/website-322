"use client";

import Image from "next/image";
import { Eye, HeartHandshake, Target, type LucideIcon } from "lucide-react";

import { Button } from "@/components/ui/button";

import { FadeIn, StaggerGroup, StaggerItem } from "./motion";
import { CONTACT } from "./site-data";
import type { NavigateFn } from "./types";

const PILLARS: Array<{ icon: LucideIcon; title: string; description: string }> = [
  {
    icon: Target,
    title: "Our Mission",
    description:
      "To make professional digital growth simple and accessible for every small and medium business, regardless of size or budget.",
  },
  {
    icon: Eye,
    title: "Our Vision",
    description:
      "To be the digital partner that businesses across Kolkata and beyond trust first — for honest work and results that last.",
  },
  {
    icon: HeartHandshake,
    title: "Our Values",
    description:
      "Honesty, clarity and commitment. We treat every client's business like our own and deliver work we are proud to sign.",
  },
];

const PRINCIPLES: Array<{ number: string; title: string }> = [
  { number: "01", title: "Client-first thinking" },
  { number: "02", title: "Clarity over jargon" },
  { number: "03", title: "Results you can measure" },
  { number: "04", title: "Long-term partnerships" },
];

interface AboutViewProps {
  onNavigate: NavigateFn;
}

export function AboutView({ onNavigate }: AboutViewProps) {
  return (
    <>
      {/* Header */}
      <section className="pt-16 pb-12 md:pt-24 md:pb-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <FadeIn className="max-w-2xl">
            <p className="text-xs font-medium uppercase tracking-[0.2em] text-neutral-500">
              About Us
            </p>
            <h1 className="mt-4 text-4xl font-semibold tracking-tight text-neutral-950 sm:text-5xl">
              The team behind your digital growth.
            </h1>
            <p className="mt-6 text-base leading-relaxed text-neutral-600 md:text-lg">
              AS Enterprise is a full-service digital agency from Kolkata,
              helping growing businesses build their presence online with
              strategy, design and technology working together.
            </p>
          </FadeIn>
        </div>
      </section>

      {/* Story */}
      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-14">
            <FadeIn className="relative order-2 lg:order-1">
              <Image
                src="/images/about-minimal.jpg"
                alt="The AS Enterprise studio in Kolkata planning client projects"
                width={1024}
                height={1024}
                className="h-auto w-full rounded-3xl border border-neutral-200 object-cover shadow-sm"
              />
            </FadeIn>
            <FadeIn delay={0.1} className="order-1 lg:order-2">
              <h2 className="text-3xl font-semibold tracking-tight text-neutral-950 md:text-4xl">
                Our story
              </h2>
              <div className="mt-6 space-y-4 text-base leading-relaxed text-neutral-600">
                <p>
                  AS Enterprise was founded in Narayanpur, Kolkata with a
                  simple belief: growing businesses deserve the same quality of
                  digital work as the big brands — without the big-agency
                  complexity or price tag.
                </p>
                <p>
                  From our first client project we have handled the full
                  journey — websites and online stores, marketing, SEO and
                  social media — so our clients can focus on running their
                  business while we take care of their digital presence.
                </p>
                <p>
                  Today, we combine strategy, design and technology to deliver
                  work that is clean, fast and measurable. No jargon, no
                  shortcuts — just honest work, clear communication and
                  results you can see.
                </p>
              </div>
              <p className="mt-6 text-sm text-neutral-500">
                Find us at {CONTACT.address}.
              </p>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Mission / Vision / Values */}
      <section className="bg-neutral-50 py-20 md:py-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <FadeIn className="mx-auto max-w-2xl text-center">
            <p className="text-xs font-medium uppercase tracking-[0.2em] text-neutral-500">
              What drives us
            </p>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight text-neutral-950 md:text-4xl">
              Mission, vision and values
            </h2>
          </FadeIn>
          <StaggerGroup className="mt-12 grid gap-6 md:grid-cols-3">
            {PILLARS.map((pillar) => (
              <StaggerItem key={pillar.title} className="h-full">
                <div className="h-full rounded-2xl border border-neutral-200 bg-white p-6 transition-shadow hover:shadow-md md:p-8">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-neutral-950 text-white">
                    <pillar.icon className="size-5" aria-hidden="true" />
                  </div>
                  <h3 className="mt-5 text-lg font-semibold tracking-tight text-neutral-950">
                    {pillar.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-neutral-600">
                    {pillar.description}
                  </p>
                </div>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* Principles */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <FadeIn className="mx-auto max-w-2xl text-center">
            <p className="text-xs font-medium uppercase tracking-[0.2em] text-neutral-500">
              How we work
            </p>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight text-neutral-950 md:text-4xl">
              Principles we stand by
            </h2>
          </FadeIn>
          <StaggerGroup className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {PRINCIPLES.map((principle) => (
              <StaggerItem key={principle.number}>
                <p
                  className="text-4xl font-semibold text-neutral-200"
                  aria-hidden="true"
                >
                  {principle.number}
                </p>
                <h3 className="mt-3 text-base font-semibold tracking-tight text-neutral-950">
                  {principle.title}
                </h3>
              </StaggerItem>
            ))}
          </StaggerGroup>

          <FadeIn className="mt-16 flex flex-wrap items-center justify-center gap-4">
            <Button
              type="button"
              onClick={() => onNavigate("services")}
              className="h-11 rounded-full bg-neutral-950 px-7 text-white hover:bg-neutral-800"
            >
              Explore Services
            </Button>
            <Button
              type="button"
              onClick={() => onNavigate("contact")}
              className="h-11 rounded-full border border-neutral-300 bg-white px-7 text-neutral-900 hover:bg-neutral-100"
            >
              Contact Us
            </Button>
          </FadeIn>
        </div>
      </section>
    </>
  );
}
