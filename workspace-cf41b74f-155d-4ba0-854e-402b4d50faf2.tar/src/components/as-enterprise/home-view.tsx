"use client";

import Image from "next/image";
import {
  ArrowRight,
  BadgeCheck,
  Crosshair,
  Headphones,
  MapPin,
  ReceiptIndianRupee,
  Sparkles,
  type LucideIcon,
} from "lucide-react";

import { Button } from "@/components/ui/button";

import { FadeIn, StaggerGroup, StaggerItem } from "./motion";
import { SectionHeading } from "./section-heading";
import { SERVICES } from "./site-data";
import type { NavigateFn } from "./types";

const TRUST_ITEMS: Array<{ icon: LucideIcon; label: string }> = [
  { icon: BadgeCheck, label: "5 specialised services" },
  { icon: MapPin, label: "Based in Kolkata, serving everywhere" },
  { icon: Headphones, label: "Personal support on call" },
];

const FEATURES: Array<{ icon: LucideIcon; title: string; description: string }> = [
  {
    icon: Crosshair,
    title: "Result-driven strategies",
    description:
      "Every campaign and build starts with a clear goal and a measurable plan to reach it.",
  },
  {
    icon: ReceiptIndianRupee,
    title: "Transparent pricing",
    description:
      "Straightforward quotes with no hidden costs. You always know what you are paying for.",
  },
  {
    icon: Headphones,
    title: "Dedicated support",
    description:
      "A real team you can reach on call — from the first brief to final delivery and beyond.",
  },
  {
    icon: Sparkles,
    title: "Modern technology",
    description:
      "We build on modern, reliable tools so your business stays fast, secure and ahead.",
  },
];

interface HomeViewProps {
  onNavigate: NavigateFn;
}

export function HomeView({ onNavigate }: HomeViewProps) {
  return (
    <>
      {/* Hero */}
      <section className="pt-16 pb-16 md:pt-24 md:pb-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-14 lg:grid-cols-2">
            <FadeIn>
              <p className="text-xs font-medium uppercase tracking-[0.2em] text-neutral-500">
                AS Enterprise · Kolkata
              </p>
              <h1 className="mt-4 text-4xl font-semibold tracking-tight text-neutral-950 sm:text-5xl lg:text-6xl">
                Digital growth, built with clarity.
              </h1>
              <p className="mt-6 max-w-xl text-base leading-relaxed text-neutral-600 md:text-lg">
                AS Enterprise helps businesses succeed online — from
                high-performance websites and e-commerce stores to marketing,
                SEO and social media that deliver measurable results.
              </p>
              <div className="mt-8 flex flex-wrap items-center gap-4">
                <Button
                  type="button"
                  onClick={() => onNavigate("services")}
                  className="h-11 rounded-full bg-neutral-950 px-7 text-white hover:bg-neutral-800"
                >
                  Explore Services
                </Button>
                <Button
                  type="button"
                  onClick={() => onNavigate("enquiry")}
                  className="h-11 rounded-full border border-neutral-300 bg-white px-7 text-neutral-900 hover:bg-neutral-100"
                >
                  Submit an Enquiry
                </Button>
              </div>
              <ul className="mt-10 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:gap-x-6">
                {TRUST_ITEMS.map((item) => (
                  <li
                    key={item.label}
                    className="flex items-center gap-2 text-sm text-neutral-600"
                  >
                    <item.icon
                      className="size-4 shrink-0 text-neutral-950"
                      aria-hidden="true"
                    />
                    {item.label}
                  </li>
                ))}
              </ul>
            </FadeIn>

            <FadeIn delay={0.1} className="relative">
              <Image
                src="/images/hero-minimal.jpg"
                alt="AS Enterprise team crafting digital experiences for clients"
                width={1024}
                height={1024}
                priority
                className="h-auto w-full rounded-3xl border border-neutral-200 object-cover shadow-sm"
              />
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Services preview */}
      <section className="bg-neutral-50 py-20 md:py-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="What we do"
            title="Services that cover your full digital journey"
            description="From your first website to scaled-up marketing — one team for everything digital."
          />
          <StaggerGroup className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map((service) => (
              <StaggerItem key={service.id} className="h-full">
                <div className="flex h-full flex-col rounded-2xl border border-neutral-200 bg-white p-6 transition-shadow hover:shadow-md md:p-8">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-neutral-950 text-white">
                    <service.icon className="size-5" aria-hidden="true" />
                  </div>
                  <h3 className="mt-5 text-lg font-semibold tracking-tight text-neutral-950">
                    {service.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-neutral-600">
                    {service.tagline}
                  </p>
                  <button
                    type="button"
                    onClick={() => onNavigate("services")}
                    className="mt-6 inline-flex min-h-11 items-center gap-1.5 self-start text-sm font-medium text-neutral-950 outline-none focus-visible:ring-2 focus-visible:ring-neutral-950 focus-visible:ring-offset-2"
                  >
                    Learn more
                    <ArrowRight className="size-4" aria-hidden="true" />
                  </button>
                </div>
              </StaggerItem>
            ))}
            <StaggerItem className="h-full">
              <div className="flex h-full flex-col rounded-2xl border border-dashed border-neutral-300 bg-white p-6 transition-shadow hover:shadow-md md:p-8">
                <h3 className="text-lg font-semibold tracking-tight text-neutral-950">
                  Need something custom?
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-neutral-600">
                  Tell us about your project and we&apos;ll tailor a solution.
                </p>
                <Button
                  type="button"
                  onClick={() => onNavigate("contact")}
                  className="mt-6 h-11 self-start rounded-full border border-neutral-300 bg-white px-7 text-neutral-900 hover:bg-neutral-100"
                >
                  Contact Us
                </Button>
              </div>
            </StaggerItem>
          </StaggerGroup>
        </div>
      </section>

      {/* Why choose us */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            eyebrow="Why choose us"
            title="A partner that treats your business like our own"
          />
          <StaggerGroup className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map((feature) => (
              <StaggerItem key={feature.title} className="h-full">
                <div className="h-full rounded-2xl border border-neutral-200 bg-white p-6 transition-shadow hover:shadow-md md:p-8">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-neutral-100 text-neutral-950">
                    <feature.icon className="size-5" aria-hidden="true" />
                  </div>
                  <h3 className="mt-5 text-base font-semibold tracking-tight text-neutral-950">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-neutral-600">
                    {feature.description}
                  </p>
                </div>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* CTA band */}
      <section className="pb-20 md:pb-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <FadeIn>
            <div className="rounded-3xl bg-neutral-950 px-8 py-14 text-center text-white md:py-16">
              <h2 className="text-3xl font-semibold tracking-tight md:text-4xl">
                Have a project in mind?
              </h2>
              <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-neutral-300">
                Tell us what you need — we usually respond within 24 hours.
              </p>
              <div className="mt-8 flex justify-center">
                <Button
                  type="button"
                  onClick={() => onNavigate("enquiry")}
                  className="h-11 rounded-full bg-white px-7 text-neutral-950 hover:bg-neutral-200"
                >
                  Submit Enquiry
                </Button>
              </div>
            </div>
          </FadeIn>
        </div>
      </section>
    </>
  );
}
