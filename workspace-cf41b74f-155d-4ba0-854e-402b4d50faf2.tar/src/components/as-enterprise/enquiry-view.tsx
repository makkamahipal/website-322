"use client";

import { useEffect, useState, type FormEvent } from "react";
import { ChevronDown, Loader2, Mail, Phone } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";


import { CONTACT, SERVICE_OPTIONS } from "./site-data";

const NEXT_STEPS: string[] = [
  "We review your enquiry",
  "We call or email you to understand requirements",
  "You get a clear quote & timeline",
];

interface FormState {
  name: string;
  email: string;
  phone: string;
  service: string;
  message: string;
}

type FieldErrors = Partial<Record<keyof FormState, string>>;

const EMPTY_FORM: FormState = {
  name: "",
  email: "",
  phone: "",
  service: "",
  message: "",
};

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

interface EnquiryViewProps {
  selectedService: string;
}

export function EnquiryView({ selectedService }: EnquiryViewProps) {
  const { toast } = useToast();
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});
  const [submitting, setSubmitting] = useState(false);

  // Prefill the service select when the user arrives via
  // "Enquire about this service" on another view.
  useEffect(() => {
    if (selectedService) {
      setForm((prev) => ({ ...prev, service: selectedService }));
      setFieldErrors((prev) => ({ ...prev, service: undefined }));
    }
  }, [selectedService]);

  const setField = (field: keyof FormState, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setFieldErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const validate = (): FieldErrors => {
    const errors: FieldErrors = {};
    if (form.name.trim().length < 2) {
      errors.name = "Please enter your full name (at least 2 characters).";
    }
    if (!EMAIL_PATTERN.test(form.email.trim())) {
      errors.email = "Please enter a valid email address.";
    }
    if (form.phone.replace(/\D/g, "").length < 10) {
      errors.phone = "Please enter a valid 10-digit phone number.";
    }
    if (!form.service) {
      errors.service = "Please select a service.";
    }
    return errors;
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const errors = validate();
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      return;
    }

    setSubmitting(true);
    try {
      const response = await fetch("/api/enquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name.trim(),
          email: form.email.trim(),
          phone: form.phone.trim(),
          service: form.service,
          message: form.message.trim(),
        }),
      });

      const data: { success?: boolean; error?: string } = await response
        .json()
        .catch(() => ({}));

      if (response.ok && data.success) {
        toast({
          title: "Enquiry submitted!",
          description: "Our team will contact you within 24 hours.",
        });
        setForm(EMPTY_FORM);
        setFieldErrors({});
      } else {
        toast({
          title: "Could not submit enquiry",
          description:
            data.error ??
            "Something went wrong on our side. Please try again in a moment.",
          variant: "destructive",
        });
      }
    } catch {
      toast({
        title: "Could not submit enquiry",
        description:
          "Network error. Please check your connection and try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="py-16 md:py-24">
      <h1 className="sr-only">Submit an enquiry to AS Enterprise</h1>
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-start gap-10 lg:grid-cols-2">
          {/* Info panel */}
          <div>
            <div className="rounded-3xl bg-neutral-950 p-8 text-white md:p-10">
              <p className="text-xs font-medium uppercase tracking-[0.2em] text-neutral-400">
                Enquiry
              </p>
              <h2 className="mt-4 text-3xl font-semibold tracking-tight text-white md:text-4xl">
                Tell us about your project
              </h2>
              <p className="mt-4 text-base leading-relaxed text-neutral-300">
                Share a few details about what you need and we will get back
                to you with a clear plan of action.
              </p>

              <h2 className="mt-10 text-sm font-semibold uppercase tracking-[0.18em] text-neutral-400">
                What happens next
              </h2>
              <ol className="mt-4 space-y-4">
                {NEXT_STEPS.map((step, index) => (
                  <li key={step} className="flex items-start gap-4">
                    <span className="flex size-7 shrink-0 items-center justify-center rounded-full border border-neutral-700 text-xs font-semibold text-white">
                      {index + 1}
                    </span>
                    <span className="pt-1 text-sm leading-relaxed text-neutral-300">
                      {step}
                    </span>
                  </li>
                ))}
              </ol>

              <div className="mt-10 space-y-3 border-t border-neutral-800 pt-8">
                <a
                  href={CONTACT.phonePrimaryHref}
                  className="flex min-h-11 items-center gap-3 text-sm font-medium text-white outline-none transition-colors hover:text-neutral-300 focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-neutral-950"
                >
                  <Phone className="size-4 shrink-0 text-neutral-400" aria-hidden="true" />
                  {CONTACT.phonePrimary}
                </a>
                <a
                  href={CONTACT.phoneSecondaryHref}
                  className="flex min-h-11 items-center gap-3 text-sm font-medium text-white outline-none transition-colors hover:text-neutral-300 focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-neutral-950"
                >
                  <Phone className="size-4 shrink-0 text-neutral-400" aria-hidden="true" />
                  {CONTACT.phoneSecondary}
                </a>
                <a
                  href={`mailto:${CONTACT.email}`}
                  className="flex min-h-11 items-center gap-3 break-all text-sm font-medium text-white outline-none transition-colors hover:text-neutral-300 focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-neutral-950"
                >
                  <Mail className="size-4 shrink-0 text-neutral-400" aria-hidden="true" />
                  {CONTACT.email}
                </a>
              </div>
            </div>
          </div>

          {/* Form */}
          <div>
            <form
              onSubmit={handleSubmit}
              noValidate
              className="rounded-2xl border border-neutral-200 bg-white p-6 md:p-8"
              aria-label="Enquiry form"
            >
              <div className="grid gap-5 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <Label htmlFor="enquiry-name" className="text-sm text-neutral-900">
                    Full Name <span className="text-neutral-500">*</span>
                  </Label>
                  <Input
                    id="enquiry-name"
                    name="name"
                    type="text"
                    autoComplete="name"
                    placeholder="Your name"
                    value={form.name}
                    onChange={(event) => setField("name", event.target.value)}
                    aria-invalid={Boolean(fieldErrors.name)}
                    aria-describedby={fieldErrors.name ? "enquiry-name-error" : undefined}
                    className="mt-2"
                  />
                  {fieldErrors.name ? (
                    <p id="enquiry-name-error" className="mt-1.5 text-sm text-red-600">
                      {fieldErrors.name}
                    </p>
                  ) : null}
                </div>

                <div>
                  <Label htmlFor="enquiry-email" className="text-sm text-neutral-900">
                    Email Address <span className="text-neutral-500">*</span>
                  </Label>
                  <Input
                    id="enquiry-email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    value={form.email}
                    onChange={(event) => setField("email", event.target.value)}
                    aria-invalid={Boolean(fieldErrors.email)}
                    aria-describedby={fieldErrors.email ? "enquiry-email-error" : undefined}
                    className="mt-2"
                  />
                  {fieldErrors.email ? (
                    <p id="enquiry-email-error" className="mt-1.5 text-sm text-red-600">
                      {fieldErrors.email}
                    </p>
                  ) : null}
                </div>

                <div>
                  <Label htmlFor="enquiry-phone" className="text-sm text-neutral-900">
                    Phone Number <span className="text-neutral-500">*</span>
                  </Label>
                  <Input
                    id="enquiry-phone"
                    name="phone"
                    type="tel"
                    autoComplete="tel"
                    placeholder="10-digit mobile number"
                    value={form.phone}
                    onChange={(event) => setField("phone", event.target.value)}
                    aria-invalid={Boolean(fieldErrors.phone)}
                    aria-describedby={fieldErrors.phone ? "enquiry-phone-error" : undefined}
                    className="mt-2"
                  />
                  {fieldErrors.phone ? (
                    <p id="enquiry-phone-error" className="mt-1.5 text-sm text-red-600">
                      {fieldErrors.phone}
                    </p>
                  ) : null}
                </div>

                <div className="sm:col-span-2">
                  <Label htmlFor="enquiry-service" className="text-sm text-neutral-900">
                    Service Interested <span className="text-neutral-500">*</span>
                  </Label>
                  {/* Native select styled like the shadcn trigger. A Radix
                      Select would reset a programmatically prefilled value:
                      its hidden bubble input has no <option> registered until
                      the dropdown opens, so the native element coerces the
                      value back to "" and fires onValueChange(""). */}
                  <div className="relative mt-2">
                    <select
                      id="enquiry-service"
                      name="service"
                      aria-label="Service interested"
                      aria-invalid={Boolean(fieldErrors.service)}
                      value={form.service}
                      onChange={(event) => setField("service", event.target.value)}
                      className="flex h-11 w-full appearance-none rounded-md border border-input bg-transparent px-3 py-1 pr-10 text-sm shadow-xs transition-[color,box-shadow] outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-destructive/20"
                    >
                      <option value="">Select a service</option>
                      {SERVICE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                    <ChevronDown
                      className="pointer-events-none absolute top-1/2 right-3.5 size-4 -translate-y-1/2 text-neutral-500"
                      aria-hidden="true"
                    />
                  </div>
                  {fieldErrors.service ? (
                    <p id="enquiry-service-error" className="mt-1.5 text-sm text-red-600">
                      {fieldErrors.service}
                    </p>
                  ) : null}
                </div>

                <div className="sm:col-span-2">
                  <Label htmlFor="enquiry-message" className="text-sm text-neutral-900">
                    Message
                  </Label>
                  <Textarea
                    id="enquiry-message"
                    name="message"
                    rows={5}
                    placeholder="Tell us briefly about your project or requirement..."
                    value={form.message}
                    onChange={(event) => setField("message", event.target.value)}
                    className="mt-2 resize-none"
                  />
                </div>
              </div>

              <Button
                type="submit"
                disabled={submitting}
                className="mt-6 h-11 w-full rounded-full bg-neutral-950 px-7 text-white hover:bg-neutral-800"
              >
                {submitting ? (
                  <>
                    <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                    Submitting...
                  </>
                ) : (
                  "Submit Enquiry"
                )}
              </Button>
              <p className="mt-4 text-center text-xs text-neutral-500">
                We respect your privacy — your details are only used to respond
                to your enquiry.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
