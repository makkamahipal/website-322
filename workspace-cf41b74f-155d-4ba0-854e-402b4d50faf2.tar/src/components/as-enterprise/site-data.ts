import {
  Code2,
  Megaphone,
  Share2,
  ShoppingCart,
  TrendingUp,
  type LucideIcon,
} from "lucide-react";

export interface ServiceItem {
  id: string;
  title: string;
  icon: LucideIcon;
  tagline: string;
  bullets: string[];
}

export const SERVICES: ServiceItem[] = [
  {
    id: "digital-marketing",
    title: "Digital Marketing",
    icon: Megaphone,
    tagline: "Data-driven campaigns that turn clicks into customers.",
    bullets: [
      "Performance marketing & paid ads (Google & Meta)",
      "Content & email marketing",
      "Conversion tracking & analytics",
      "Campaign strategy & brand positioning",
    ],
  },
  {
    id: "ecommerce",
    title: "E-commerce",
    icon: ShoppingCart,
    tagline: "Launch and scale your online store, end to end.",
    bullets: [
      "Store setup on leading platforms",
      "Product listing & catalogue management",
      "Payment gateway & shipping integration",
      "Sales funnel & conversion optimisation",
    ],
  },
  {
    id: "seo",
    title: "SEO",
    icon: TrendingUp,
    tagline: "Rank higher, get found, grow organic traffic.",
    bullets: [
      "Keyword research & on-page SEO",
      "Technical SEO & site audits",
      "Local SEO for Kolkata & beyond",
      "Link building & content strategy",
    ],
  },
  {
    id: "social-media-marketing",
    title: "Social Media Marketing",
    icon: Share2,
    tagline: "Build a brand people follow, like and trust.",
    bullets: [
      "Content planning & creation",
      "Page management & community handling",
      "Paid social campaigns",
      "Monthly growth reporting",
    ],
  },
  {
    id: "website-development",
    title: "Website Development",
    icon: Code2,
    tagline: "Fast, modern websites built to convert.",
    bullets: [
      "Business & portfolio websites",
      "Responsive mobile-first design",
      "E-commerce & booking websites",
      "Ongoing maintenance & support",
    ],
  },
];

export const SERVICE_OPTIONS: string[] = [
  ...SERVICES.map((service) => service.title),
  "Other",
];

export const CONTACT = {
  phonePrimary: "+91 8100282187",
  phonePrimaryHref: "tel:+918100282187",
  phoneSecondary: "+91 9051889425",
  phoneSecondaryHref: "tel:+919051889425",
  email: "asenterprise0809@gmail.com",
  address: "Sir Ramesh Mitra Road, Narayanpur, Kolkata - 700132",
} as const;

export const LOGO_SRC = "/as-enterprise-logo.jpeg" as const;
