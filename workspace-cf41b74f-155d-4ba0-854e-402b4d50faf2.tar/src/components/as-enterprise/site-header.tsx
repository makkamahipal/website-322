"use client";

import { useState } from "react";
import Image from "next/image";
import { Mail, Menu, Phone } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { CONTACT, LOGO_SRC } from "./site-data";
import type { NavigateFn, View } from "./types";

const NAV_ITEMS: Array<{ label: string; view: View }> = [
  { label: "Home", view: "home" },
  { label: "About Us", view: "about" },
  { label: "Services", view: "services" },
  { label: "Contact Us", view: "contact" },
  { label: "Enquiry", view: "enquiry" },
];

interface SiteHeaderProps {
  view: View;
  onNavigate: NavigateFn;
}

export function SiteHeader({ view, onNavigate }: SiteHeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleNavigate = (next: View) => {
    setMenuOpen(false);
    onNavigate(next);
  };

  return (
    <header className="sticky top-0 z-50 border-b border-neutral-200/70 bg-white/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6 md:h-18 lg:px-8">
        <button
          type="button"
          onClick={() => handleNavigate("home")}
          className="flex min-h-11 items-center gap-3 rounded-lg text-left outline-none focus-visible:ring-2 focus-visible:ring-neutral-950 focus-visible:ring-offset-2"
          aria-label="AS Enterprise - go to home"
        >
          <Image
            src={LOGO_SRC}
            alt="AS Enterprise logo"
            width={44}
            height={44}
            priority
            className="h-11 w-11 rounded-lg border border-neutral-200 object-cover"
          />
          <span className="flex flex-col gap-0.5 leading-none">
            <span className="text-lg font-semibold tracking-tight text-neutral-950">
              AS Enterprise
            </span>
            <span className="text-[11px] uppercase tracking-[0.18em] text-neutral-500">
              Digital Solutions · Kolkata
            </span>
          </span>
        </button>

        <nav aria-label="Primary" className="hidden items-center gap-7 md:flex">
          {NAV_ITEMS.map((item) => {
            const active = view === item.view;
            return (
              <button
                key={item.view}
                type="button"
                onClick={() => handleNavigate(item.view)}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "text-sm font-medium outline-none transition-colors focus-visible:ring-2 focus-visible:ring-neutral-950 focus-visible:ring-offset-2",
                  active
                    ? "text-neutral-950 underline decoration-neutral-950 decoration-2 underline-offset-[6px]"
                    : "text-neutral-600 hover:text-neutral-950"
                )}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center gap-3">
          <Button
            type="button"
            onClick={() => handleNavigate("enquiry")}
            className="hidden h-11 rounded-full bg-neutral-950 px-7 text-white hover:bg-neutral-800 lg:inline-flex"
          >
            Get a Quote
          </Button>

          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button
                type="button"
                variant="outline"
                size="icon"
                aria-label="Open navigation menu"
                className="h-11 w-11 rounded-full border-neutral-300 bg-white text-neutral-900 hover:bg-neutral-100 md:hidden"
              >
                <Menu className="size-5" />
              </Button>
            </SheetTrigger>
            <SheetContent
              side="right"
              className="flex w-4/5 flex-col gap-0 border-neutral-200 p-0 sm:max-w-sm"
            >
              <SheetHeader className="border-b border-neutral-200 p-6 text-left">
                <SheetTitle className="text-lg font-semibold tracking-tight text-neutral-950">
                  AS Enterprise
                </SheetTitle>
                <SheetDescription className="text-xs uppercase tracking-[0.18em] text-neutral-500">
                  Digital Solutions · Kolkata
                </SheetDescription>
              </SheetHeader>

              <nav aria-label="Mobile" className="flex flex-col p-4">
                {NAV_ITEMS.map((item) => {
                  const active = view === item.view;
                  return (
                    <button
                      key={item.view}
                      type="button"
                      onClick={() => handleNavigate(item.view)}
                      aria-current={active ? "page" : undefined}
                      className={cn(
                        "min-h-11 rounded-lg px-4 py-3 text-left text-base font-medium outline-none transition-colors focus-visible:ring-2 focus-visible:ring-neutral-950",
                        active
                          ? "bg-neutral-100 text-neutral-950"
                          : "text-neutral-600 hover:bg-neutral-50 hover:text-neutral-950"
                      )}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </nav>

              <div className="mt-auto space-y-3 border-t border-neutral-200 p-6">
                <a
                  href={CONTACT.phonePrimaryHref}
                  className="flex min-h-11 items-center gap-3 text-sm font-medium text-neutral-950 outline-none focus-visible:ring-2 focus-visible:ring-neutral-950 focus-visible:ring-offset-2"
                >
                  <Phone className="size-4 text-neutral-500" aria-hidden="true" />
                  {CONTACT.phonePrimary}
                </a>
                <a
                  href={CONTACT.phoneSecondaryHref}
                  className="flex min-h-11 items-center gap-3 text-sm font-medium text-neutral-950 outline-none focus-visible:ring-2 focus-visible:ring-neutral-950 focus-visible:ring-offset-2"
                >
                  <Phone className="size-4 text-neutral-500" aria-hidden="true" />
                  {CONTACT.phoneSecondary}
                </a>
                <a
                  href={`mailto:${CONTACT.email}`}
                  className="flex min-h-11 items-center gap-3 break-all text-sm font-medium text-neutral-950 outline-none focus-visible:ring-2 focus-visible:ring-neutral-950 focus-visible:ring-offset-2"
                >
                  <Mail className="size-4 shrink-0 text-neutral-500" aria-hidden="true" />
                  {CONTACT.email}
                </a>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
